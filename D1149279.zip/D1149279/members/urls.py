from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('members/', views.members, name='members'),
    path('members/details/<int:id>', views.details, name='details'),
    path('testing/', views.testing, name='testing'),
]

# urlpatterns = [
#     path('court/', views.all_courts, name='all_courts'),
#     path('court/<int:court_id>/', views.court_details, name='court_details'),
#     # 新增球場url
# ]