from django.shortcuts import render
from .models import Member, Court

# def members(request):
#     mymembers = Member.objects.all()
#     return render(request, 'all_members.html', {'mymembers': mymembers})

# def details(request, id):
#     mymember = Member.objects.get(id=id)
#     return render(request, 'details.html', {'mymember': mymember})

def court_detail(request, court_id):
    mycourt = Court.objects.get(id=court_id)
    return render(request, 'court_detail.html', {'mycourt': mycourt})

def all_court(request):
    mycourt = Court.objects.all().values()
    return render(request, 'all_court.html', {'mycourt': mycourt})

def main(request):
    return render(request, 'main.html')

def testing(request):
    context = {'fruits': ['Apple', 'Banana', 'Cherry']}
    return render(request, 'template.html', context)
