from django.contrib import admin
from .models import Court

#加入court admin
class CourtAdmin(admin.ModelAdmin):
  list_display = ("court_name", "court_type", "city")

admin.site.register(Court, CourtAdmin)
# admin.site.register(Member)


