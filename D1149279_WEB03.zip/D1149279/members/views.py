from django.shortcuts import render
from .models import Member, Court

def members(request):
    mymembers = Member.objects.all()
    return render(request, 'all_members.html', {'mymembers': mymembers})

def details(request, id):
    mymember = Member.objects.get(id=id)
    return render(request, 'details.html', {'mymember': mymember})

def court_detail(request, id):
    court = Court.objects.get(id=id)
    return render(request, 'court_detail.html', {'court': court})

def all_court(request):
    courts = Court.objects.all()
    return render(request, 'all_court.html', {'courts': courts})

def main(request):
    return render(request, 'main.html')

def testing(request):
    context = {'fruits': ['Apple', 'Banana', 'Cherry']}
    return render(request, 'template.html', context)
